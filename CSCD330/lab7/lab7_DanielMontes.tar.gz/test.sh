#!/usr/bin/env

sudo python3 lab7.py google.com 9
echo
sudo python3 lab7.py yahoo.com 15
echo
sudo python3 lab7.py facebook.com 20