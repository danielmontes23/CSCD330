#!/usr/bin/env bash


curl http://127.0.0.1:5000/address/google.com
echo
curl http://127.0.0.1:5000/address/google.com
echo
curl http://127.0.0.1:5000/weather/google.com
echo
curl http://127.0.0.1:5000/weather/google.com