#!/usr/bin/env

python3 lab2.py google.com
echo
python3 lab2.py yahoo.com
echo
python3 lab2.py amazon.com